import React from 'react'

function Footer() {
  return (
    <div>copyright. all right reserved.</div>
  )
}

export default Footer