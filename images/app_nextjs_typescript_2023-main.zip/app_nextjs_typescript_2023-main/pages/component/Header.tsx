import React from 'react'

function Header() {
  return (
    <h1>로고</h1>
  )
}

export default Header